Hey, over the next coming days we'd like to do something a little bit different. We thought it would be fun to ask people what they wanted to learn about.

If you could take just 5 minutes and tell me what is the single biggest challenge that you’re struggling with in your study right now… Even if you could take 30 seconds to tell me what that is, a) it would mean the world to me and b), most importantly, I’ll be able to use that information to gear my upcoming emails toward topics you specifically want to know more about.

https://forms.gle/v3L8BNzVaaWwjikN8

As a way of saying thanks for your feedback, you’ll receive a beautiful CV template for job or internship application.
